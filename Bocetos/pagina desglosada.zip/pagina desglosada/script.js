// Variables globales del carrito
let cart = [];

const cartToggle = document.querySelector('.cart-toggle');
const cartCountElem = document.getElementById('cartCount');
const cartSidebar = document.getElementById('cartSidebar');
const cartOverlay = document.getElementById('cartOverlay');
const cartItemsContainer = document.getElementById('cartItemsContainer');
const cartTotalContainer = document.getElementById('cartTotalContainer');
const cartTotalAmount = document.getElementById('cartTotalAmount');
const checkoutButton = document.getElementById('checkoutButton');
const mobileNav = document.getElementById('mobileNav');
const mobileToggleBtn = document.querySelector('.mobile-toggle');

// Muestra/oculta el menú móvil
function toggleMobileMenu() {
  const isShown = mobileNav.classList.toggle('show');
  mobileNav.hidden = !isShown;
  mobileToggleBtn.setAttribute('aria-expanded', isShown);
}

// Abre o cierra el carrito lateral
function toggleCart() {
  const isVisible = cartSidebar.classList.toggle('show');
  cartOverlay.classList.toggle('show', isVisible);
  document.body.style.overflow = isVisible ? 'hidden' : 'auto';

  // Accesibilidad: enfocar el botón adecuado
  if(isVisible) {
    checkoutButton.focus();
  } else {
    cartToggle.focus();
  }
}

// Actualiza la cantidad de viajes en el carrito (ícono superior)
function updateCartCount() {
  cartCountElem.textContent = cart.length;
  cartCountElem.setAttribute('aria-label', `Carrito con ${cart.length} ${cart.length === 1 ? 'viaje' : 'viajes'}`);
}

// Muestra los productos en el carrito
function updateCartDisplay() {
  if(cart.length === 0) {
    cartItemsContainer.innerHTML = `<div class="cart-empty-text">
      <span class="material-icons">shopping_cart</span>Tu carrito está vacío
    </div>`;
    cartTotalContainer.hidden = true;
    checkoutButton.disabled = true;
    return;
  }

  // Crea HTML para cada ítem
  cartItemsContainer.innerHTML = cart.map((item, idx) => `
    <div class="cart-item">
      <div class="cart-item-name">${item.name}</div>
      <div class="cart-item-price">$${item.price.toLocaleString()}</div>
      <button class="cart-item-remove-btn" onclick="removeFromCart(${idx})">&times;</button>
    </div>
  `).join('');

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  cartTotalAmount.textContent = total.toLocaleString();
  cartTotalContainer.hidden = false;
  checkoutButton.disabled = false;
}

// Agrega un destino al carrito
function addToCart(name, price) {
  cart.push({ name, price });
  updateCartCount();
  updateCartDisplay();
  showNotification(`Agregaste ${name} al carrito`, 'success');
}

// Elimina un ítem del carrito
function removeFromCart(index) {
  const removed = cart[index];
  cart.splice(index, 1);
  updateCartCount();
  updateCartDisplay();
  showNotification(`Eliminaste ${removed.name} del carrito`, 'info');
}

// Simula un proceso de compra
function checkout() {
  if (cart.length === 0) return;

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  showNotification('Procesando tu pago...', 'info');

  setTimeout(() => {
    alert(`Gracias por tu compra! Total: $${total.toLocaleString()}`);
    cart = [];
    updateCartCount();
    updateCartDisplay();
    toggleCart();
    showNotification('Compra realizada con éxito', 'success');
  }, 2000);
}

// Muestra un mensaje emergente tipo alerta
function showNotification(message, type = 'info') {
  const notif = document.createElement('div');
  notif.textContent = message;
  notif.style = `
    position: fixed; top: 20px; right: 20px;
    padding: 18px 26px; border-radius: 16px;
    font-weight: 600; font-size: 1rem; z-index: 2000;
    background-color: ${type === 'success' ? '#d4edda' : '#d1ecf1'};
    color: ${type === 'success' ? '#155724' : '#0c5460'};
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    opacity: 0; transition: opacity 0.4s ease;
  `;
  document.body.appendChild(notif);
  requestAnimationFrame(() => notif.style.opacity = '1');
  setTimeout(() => {
    notif.style.opacity = '0';
    notif.addEventListener('transitionend', () => notif.remove(), { once: true });
  }, 3000);
}

// Soporte de teclado para el botón del carrito
cartToggle.addEventListener('keydown', e => {
  if (e.key === 'Enter' || e.key === ' ') {
    toggleCart();
    e.preventDefault();
  }
});

// Oculta el menú móvil si cambia el tamaño de la pantalla
window.addEventListener('resize', () => {
  if (window.innerWidth > 1024 && mobileNav.classList.contains('show')) {
    toggleMobileMenu();
  }
});

// Cierra menú móvil al hacer click fuera
document.addEventListener('click', e => {
  if (mobileNav.classList.contains('show') &&
      !mobileNav.contains(e.target) &&
      !mobileToggleBtn.contains(e.target)) {
    toggleMobileMenu();
  }
});

// Inicializa la vista del carrito al cargar la página
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
  updateCartDisplay();
});
